import os

from tinydb import TinyDB

from config import DATA_DIR

os.makedirs(DATA_DIR, exist_ok=True)

users_db = TinyDB(os.path.join(DATA_DIR, "users.json"))
tasks_db = TinyDB(os.path.join(DATA_DIR, "tasks.json"))
teams_db = TinyDB(os.path.join(DATA_DIR, "teams.json"))
