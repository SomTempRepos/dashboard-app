import uuid
from datetime import datetime

from fastapi import HTTPException, status
from tinydb import Query

from models.task_model import TaskCreate, TaskResponse, TaskStatusUpdate, TaskUpdate
from models.user_model import UserResponse
from utils.db import tasks_db, teams_db, users_db


def _task_to_response(task: dict) -> TaskResponse:
    return TaskResponse(
        id=task["id"],
        title=task["title"],
        description=task["description"],
        status=task["status"],
        priority=task["priority"],
        assigned_to=task["assigned_to"],
        team_id=task.get("team_id"),
        created_by=task["created_by"],
        due_date=task.get("due_date"),
        created_at=task["created_at"],
    )


def create_task(task_data: TaskCreate, current_user: UserResponse) -> TaskResponse:
    User = Query()
    resolved_assigned_to = []
    for email in task_data.assigned_to:
        user = users_db.get(User.email == email)
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Assigned user with email {email} does not exist",
            )
        resolved_assigned_to.append(user["id"])

    resolved_team_id = None
    if task_data.team_code is not None:
        Team = Query()
        team = teams_db.get(Team.team_code == task_data.team_code)
        if team is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Team with that code does not exist",
            )
        if current_user.id not in team["member_ids"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You are not a member of this team",
            )
        resolved_team_id = team["id"]

    task = {
        "id": str(uuid.uuid4()),
        "title": task_data.title,
        "description": task_data.description,
        "status": task_data.status,
        "priority": task_data.priority,
        "assigned_to": resolved_assigned_to,
        "team_id": resolved_team_id,
        "created_by": current_user.id,
        "due_date": task_data.due_date,
        "created_at": datetime.utcnow().isoformat(),
    }

    tasks_db.insert(task)

    return _task_to_response(task)
def get_my_tasks(current_user: UserResponse) -> list:
    Task = Query()
    tasks = tasks_db.search(
        (Task.created_by == current_user.id)
        | (Task.assigned_to.any([current_user.id]))
    )
    return [_task_to_response(task) for task in tasks]


def get_team_tasks(team_id: str, current_user: UserResponse) -> list:
    Team = Query()
    team = teams_db.get(Team.id == team_id)
    if team is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Team not found",
        )

    if current_user.id not in team["member_ids"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You are not a member of this team",
        )

    Task = Query()
    tasks = tasks_db.search(Task.team_id == team_id)
    return [_task_to_response(task) for task in tasks]


def update_task(
    task_id: str, task_data: TaskUpdate, current_user: UserResponse
) -> TaskResponse:
    Task = Query()
    task = tasks_db.get(Task.id == task_id)
    if task is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found",
        )

    if task["created_by"] != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only the creator can update this task",
        )

    update_data = task_data.dict(exclude_unset=True)

    if "assigned_to" in update_data:
        User = Query()
        resolved_assigned_to = []
        for email in update_data["assigned_to"]:
            user = users_db.get(User.email == email)
            if user is None:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Assigned user with email {email} does not exist",
                )
            resolved_assigned_to.append(user["id"])
        update_data["assigned_to"] = resolved_assigned_to

    if "team_code" in update_data:
        team_code = update_data.pop("team_code")
        if team_code is None:
            update_data["team_id"] = None
        else:
            Team = Query()
            team = teams_db.get(Team.team_code == team_code)
            if team is None:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Team with that code does not exist",
                )
            if current_user.id not in team["member_ids"]:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You are not a member of this team",
                )
            update_data["team_id"] = team["id"]

    tasks_db.update(update_data, Task.id == task_id)

    updated_task = tasks_db.get(Task.id == task_id)
    return _task_to_response(updated_task)
def delete_task(task_id: str, current_user: UserResponse) -> dict:
    Task = Query()
    task = tasks_db.get(Task.id == task_id)
    if task is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found",
        )

    if task["created_by"] != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only the creator can delete this task",
        )

    tasks_db.remove(Task.id == task_id)

    return {"message": "task deleted successfully"}


def update_task_status(
    task_id: str, status_update: TaskStatusUpdate, current_user: UserResponse
) -> TaskResponse:
    Task = Query()
    task = tasks_db.get(Task.id == task_id)
    if task is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found",
        )

    if current_user.id not in task["assigned_to"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only an assigned user can update the status",
        )

    tasks_db.update({"status": status_update.status}, Task.id == task_id)

    updated_task = tasks_db.get(Task.id == task_id)
    return _task_to_response(updated_task)
