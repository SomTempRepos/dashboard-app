from fastapi import APIRouter, Depends, HTTPException, status
from tinydb import Query

from models.user_model import UserResponse, UserUpdate
from services.auth_service import get_current_user
from utils.db import users_db

router = APIRouter()


@router.get("/me", response_model=UserResponse, status_code=status.HTTP_200_OK)
def get_me(current_user: UserResponse = Depends(get_current_user)):
    return current_user


@router.get("/lookup", response_model=UserResponse, status_code=status.HTTP_200_OK)
def lookup_user_by_email(
    email: str, current_user: UserResponse = Depends(get_current_user)
):
    User = Query()
    user = users_db.get(User.email == email)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )
    return UserResponse(
        id=user["id"],
        name=user["name"],
        email=user["email"],
        user_code=user["user_code"],
        team_ids=user["team_ids"],
        created_at=user["created_at"],
    )


@router.get("/by-code/{user_code}", response_model=UserResponse, status_code=status.HTTP_200_OK)
def lookup_user_by_code(
    user_code: str, current_user: UserResponse = Depends(get_current_user)
):
    User = Query()
    user = users_db.get(User.user_code == user_code)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )
    return UserResponse(
        id=user["id"],
        name=user["name"],
        email=user["email"],
        user_code=user["user_code"],
        team_ids=user["team_ids"],
        created_at=user["created_at"],
    )


@router.put("/me", response_model=UserResponse, status_code=status.HTTP_200_OK)
def update_me(
    user_data: UserUpdate, current_user: UserResponse = Depends(get_current_user)
):
    User = Query()

    update_data = user_data.dict(exclude_unset=True)

    if "email" in update_data and update_data["email"] != current_user.email:
        existing = users_db.get(User.email == update_data["email"])
        if existing is not None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email already taken",
            )

    users_db.update(update_data, User.id == current_user.id)

    updated_user = users_db.get(User.id == current_user.id)
    return UserResponse(
        id=updated_user["id"],
        name=updated_user["name"],
        email=updated_user["email"],
        user_code=updated_user["user_code"],
        team_ids=updated_user["team_ids"],
        created_at=updated_user["created_at"],
    )


@router.delete("/me", status_code=status.HTTP_200_OK)
def delete_me(current_user: UserResponse = Depends(get_current_user)):
    User = Query()
    users_db.remove(User.id == current_user.id)
    return {"message": "user deleted successfully"}